<nav class="navbar navbar-expand-sm navbar-light bg-light sticky-top">
	<div class="container">
        <a class="navbar-brand" href="index.php"><img src="image/favicon.jpg" width="30" height="30" class="rounded-circle">Blood Bank Management System</a>

			<div class="collapse navbar-collapse" id="collapsibleNavbar">


				<ul class="navbar-nav ml-auto">
					<li class="nav-item">
						<a class="nav-link btn btn-light" href="Userpage.html">Home</a>
						<li class="nav-item">
						<a class="nav-link btn btn-light" href="logout.php">LogOut</a>
					</li>
				

				</ul>


			</div>
		</div>
	</nav>